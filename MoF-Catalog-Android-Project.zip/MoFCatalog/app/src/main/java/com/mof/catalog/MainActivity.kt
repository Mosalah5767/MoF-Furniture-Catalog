package com.mof.catalog

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

private const val GOLD = 0xFFC99B3B.toInt()
private const val BLACK = 0xFF101010.toInt()
private const val PREFS = "mof_catalog"

data class Product(var id:String, var nameAr:String, var nameEn:String, var category:String, var price:Double, var discount:Double, var stock:Int, var description:String, var photos:MutableList<String>, var available:Boolean=true) {
    fun finalPrice() = price * (1.0 - discount.coerceIn(0.0,100.0)/100.0)
    fun json() = JSONObject().put("id",id).put("nameAr",nameAr).put("nameEn",nameEn).put("category",category).put("price",price).put("discount",discount).put("stock",stock).put("description",description).put("photos",JSONArray(photos)).put("available",available)
    companion object { fun from(o:JSONObject):Product { val a=o.optJSONArray("photos")?:JSONArray(); val p=mutableListOf<String>(); for(i in 0 until a.length()) p.add(a.optString(i)); return Product(o.optString("id"),o.optString("nameAr"),o.optString("nameEn"),o.optString("category","الأثاث"),o.optDouble("price"),o.optDouble("discount"),o.optInt("stock"),o.optString("description"),p,o.optBoolean("available",true)) } }
}

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var products = mutableListOf<Product>()
    private var english = false
    private var listMode = false
    private var admin = false
    private var editing: Product? = null
    private var photoTarget: Product? = null
    private val photoRequestCode = 4102
    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==photoRequestCode && resultCode==RESULT_OK && data!=null) {
            val target=photoTarget ?: return
            val chosen=mutableListOf<Uri>()
            data.clipData?.let { clip -> for(i in 0 until clip.itemCount) chosen.add(clip.getItemAt(i).uri) }
            if(chosen.isEmpty()) data.data?.let { chosen.add(it) }
            target.photos.clear()
            chosen.take(3).forEach { uri -> try { contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch(_:Exception) {}; target.photos.add(uri.toString()) }
            save(); if(editing===target) showProductForm(target) else render()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); load(); render() }
    private fun s(ar:String,en:String)=if(english) en else ar
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun save(){ val a=JSONArray(); products.forEach{a.put(it.json())}; getSharedPreferences(PREFS,0).edit().putString("products",a.toString()).apply() }
    private fun load(){ val raw=getSharedPreferences(PREFS,0).getString("products",null); if(raw!=null) try { val a=JSONArray(raw); for(i in 0 until a.length()) products.add(Product.from(a.getJSONObject(i))) }catch(_:Exception){} }
    private fun text(t:String,size:Float=15f,color:Int=Color.WHITE,bold:Boolean=false):TextView = TextView(this).apply { text=t; textSize=size; setTextColor(color); if(bold) setTypeface(null,1); gravity=Gravity.CENTER_VERTICAL }
    private fun button(t:String, action:()->Unit):Button=Button(this).apply { text=t; setTextColor(Color.BLACK); setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD)); setOnClickListener{action()} }
    private fun render(query:String="") {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(BLACK); setPadding(dp(16),dp(12),dp(16),dp(12)) }
        setContentView(root)
        val top=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; orientation=LinearLayout.HORIZONTAL }
        top.addView(text("Mo.F",25f,GOLD,true),LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(button(if(english)"العربية" else "English"){english=!english;render(query)})
        top.addView(button(s("الإدارة","Admin")){login()})
        root.addView(top)
        root.addView(text(s("كتالوج الأثاث الفاخر","LUXURY FURNITURE CATALOG"),12f,GOLD,true))
        val search=EditText(this).apply { hint=s("ابحث باسم المنتج أو رقمه...","Search products or ID..."); setHintTextColor(0xFF999999.toInt()); setTextColor(Color.WHITE); setSingleLine(true); setPadding(dp(12),0,dp(12),0); setBackgroundColor(0xFF242424.toInt()) }
        root.addView(search,LinearLayout.LayoutParams(-1,dp(48)))
        val controls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        controls.addView(text(s("المنتجات: ${products.size}","Products: ${products.size}"),14f,GOLD,true),LinearLayout.LayoutParams(0,dp(44),1f))
        controls.addView(button(if(listMode)s("عرض شبكي","Grid") else s("عرض قائمة","List")){listMode=!listMode;render(search.text.toString())})
        root.addView(controls)
        val scroll=ScrollView(this); val items=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        populateItems(items, query)
        scroll.addView(items); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){populateItems(items,s?.toString()?:"")};override fun afterTextChanged(e:android.text.Editable?) {}})
    }
    private fun populateItems(items:LinearLayout, query:String) {
        items.removeAllViews()
        val filtered=products.filter { query.isBlank() || it.id.contains(query,true)||it.nameAr.contains(query,true)||it.nameEn.contains(query,true)||it.category.contains(query,true) }
        if(filtered.isEmpty()) items.addView(text(s("لا توجد منتجات بعد. افتح لوحة الإدارة لإضافة أول منتج.","No products yet. Open Admin to add your first product."),15f,0xFFBBBBBB.toInt()))
        if(listMode) filtered.forEach { p -> items.addView(productRow(p)) } else {
            filtered.chunked(2).forEach { pair ->
                val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
                pair.forEach { p -> row.addView(productCard(p),LinearLayout.LayoutParams(0,dp(235),1f).apply { setMargins(dp(4),dp(5),dp(4),dp(5)) }) }
                if(pair.size==1) row.addView(View(this),LinearLayout.LayoutParams(0,dp(235),1f))
                items.addView(row)
            }
        }
    }
    private fun productCard(p:Product):View { val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(8),dp(8),dp(8));setBackgroundColor(0xFF202020.toInt());setOnClickListener{details(p)}}; box.addView(photo(p,dp(130))); box.addView(text(if(english)p.nameEn.ifBlank{p.nameAr}else p.nameAr,15f,Color.WHITE,true)); box.addView(text("#${p.id}",11f,0xFFBBBBBB.toInt())); box.addView(text("${"%.2f".format(p.finalPrice())} SAR",15f,GOLD,true)); return box }
    private fun productRow(p:Product):View { val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(6),dp(6),dp(6),dp(6));setBackgroundColor(0xFF202020.toInt());setOnClickListener{details(p)}}; row.addView(photo(p,dp(90)),LinearLayout.LayoutParams(dp(100),dp(90))); val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}; col.addView(text(if(english)p.nameEn.ifBlank{p.nameAr}else p.nameAr,15f,Color.WHITE,true)); col.addView(text("#${p.id}  •  ${p.category}",12f,0xFFBBBBBB.toInt())); col.addView(text("${"%.2f".format(p.finalPrice())} SAR",15f,GOLD,true)); row.addView(col); return row }
    private fun photo(p:Product,h:Int):View { val frame=FrameLayout(this).apply{setBackgroundColor(0xFF333333.toInt())}; val img=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP}; if(p.photos.isNotEmpty()) try{img.setImageURI(Uri.parse(p.photos[0]))}catch(_:Exception){}; frame.addView(img,FrameLayout.LayoutParams(-1,h)); if(p.photos.isEmpty()) frame.addView(text("Mo.F",22f,GOLD,true).apply{gravity=Gravity.CENTER}); return frame }
    private fun details(p:Product){ val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(12),dp(18),dp(12))}; box.addView(text(if(english)p.nameEn.ifBlank{p.nameAr}else p.nameAr,21f,GOLD,true)); box.addView(text("${s("رقم المنتج","Product ID")}: ${p.id}")); box.addView(text("${"%.2f".format(p.finalPrice())} SAR",20f,GOLD,true)); box.addView(text("${s("السعر قبل الخصم","Original price")}: ${p.price} SAR   •   ${s("الخصم","Discount")}: ${p.discount}%")); box.addView(text("${s("المخزون","Stock")}: ${p.stock}")); box.addView(text(p.description)); val d=AlertDialog.Builder(this).setView(box).setPositiveButton(s("اتصال بالمعرض","Call showroom")){_,_->callShowroom()}.setNegativeButton(s("إغلاق","Close"),null).create(); d.show() }
    private fun callShowroom(){ val phone=getSharedPreferences(PREFS,0).getString("phone","")?:""; if(phone.isBlank()){AlertDialog.Builder(this).setMessage(s("أضف رقم هاتف المعرض من إعدادات الإدارة أولاً.","Add the showroom phone number in Admin settings first.")).setPositiveButton("OK",null).show()}else try{startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:$phone")))}catch(_:Exception){} }
    private fun login(){ val input=EditText(this).apply{hint=s("كلمة مرور الإدارة","Admin PIN");inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD}; AlertDialog.Builder(this).setTitle(s("دخول الإدارة","Admin login")).setView(input).setPositiveButton(s("دخول","Enter")){_,_-> val pin=getSharedPreferences(PREFS,0).getString("pin","1234"); if(input.text.toString()==pin){admin=true;adminPanel()}else Toast.makeText(this,s("كلمة المرور غير صحيحة","Incorrect PIN"),Toast.LENGTH_SHORT).show()}.setNegativeButton(s("إلغاء","Cancel"),null).show() }
    private fun adminPanel(){ val opts=arrayOf(s("إضافة منتج","Add product"),s("إدارة المنتجات","Manage products"),s("إعدادات المعرض","Showroom settings")); AlertDialog.Builder(this).setTitle(s("لوحة الإدارة","Admin panel")).setItems(opts){_,which->when(which){0->showProductForm(null);1->manageProducts();2->settings()}}.setNegativeButton(s("إغلاق","Close"),null).show() }
    private fun manageProducts(){ val names=products.map{"#${it.id}  ${it.nameAr}"}.toTypedArray(); if(names.isEmpty()){showProductForm(null);return}; AlertDialog.Builder(this).setTitle(s("اختر منتجاً للتعديل","Choose product to edit")).setItems(names){_,i-> val p=products[i]; AlertDialog.Builder(this).setTitle(p.nameAr).setItems(arrayOf(s("تعديل","Edit"),s("حذف","Delete"))){_,a->if(a==0)showProductForm(p)else AlertDialog.Builder(this).setMessage(s("حذف المنتج؟","Delete product?")).setPositiveButton(s("حذف","Delete")){_,_->products.remove(p);save();render()}.setNegativeButton(s("إلغاء","Cancel"),null).show()}.show()}.setNegativeButton(s("رجوع","Back")){_,_->adminPanel()}.show() }
    private fun field(hint:String,value:String=""):EditText=EditText(this).apply{this.hint=hint;setText(value);setTextColor(Color.WHITE);setHintTextColor(0xFFAAAAAA.toInt())}
    private fun showProductForm(existing:Product?){ editing=existing; val p=existing?:Product("${(products.mapNotNull{it.id.toIntOrNull()}.maxOrNull()?:1000)+1}","","","الأثاث",0.0,0.0,0,"", mutableListOf()); val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(8));setBackgroundColor(BLACK)}; val id=field(s("رقم المنتج","Product ID"),p.id); val ar=field(s("اسم المنتج بالعربية","Arabic name"),p.nameAr); val en=field(s("اسم المنتج بالإنجليزية","English name"),p.nameEn); val cat=field(s("القسم","Category"),p.category); val price=field(s("السعر بالريال","Price SAR"),p.price.toString()); val disc=field(s("الخصم %","Discount %"),p.discount.toString()); val stock=field(s("الكمية في المخزون","Stock quantity"),p.stock.toString()); val desc=field(s("الوصف والمقاسات والخامات","Description"),p.description); listOf(id,ar,en,cat,price,disc,stock,desc).forEach{wrap.addView(it)}; val pics=button(s("اختيار حتى 3 صور","Choose up to 3 photos")){photoTarget=p; val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)};startActivityForResult(intent,photoRequestCode)}; wrap.addView(pics); wrap.addView(text("${p.photos.size}/3 ${s("صور مختارة","photos selected")}",12f,GOLD)); val scroll=ScrollView(this);scroll.addView(wrap); AlertDialog.Builder(this).setTitle(if(existing==null)s("إضافة منتج","Add product")else s("تعديل المنتج","Edit product")).setView(scroll).setPositiveButton(s("حفظ","Save")){_,_-> try{p.id=id.text.toString().trim();p.nameAr=ar.text.toString();p.nameEn=en.text.toString();p.category=cat.text.toString();p.price=price.text.toString().toDouble();p.discount=disc.text.toString().toDouble();p.stock=stock.text.toString().toInt();p.description=desc.text.toString(); if(existing==null)products.add(p);save();render()}catch(_:Exception){Toast.makeText(this,s("تحقق من السعر والخصم والمخزون","Check price, discount and stock"),Toast.LENGTH_LONG).show()}}.setNegativeButton(s("إلغاء","Cancel"),null).show() }
    private fun settings(){ val phone=field(s("رقم هاتف المعرض للاتصال","Showroom phone number"),getSharedPreferences(PREFS,0).getString("phone","")?:""); val pin=field(s("كلمة مرور الإدارة الجديدة","New admin PIN"),getSharedPreferences(PREFS,0).getString("pin","1234")?:"1234"); AlertDialog.Builder(this).setTitle(s("إعدادات المعرض","Showroom settings")).setView(LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),0);addView(phone);addView(pin)}).setPositiveButton(s("حفظ","Save")){_,_->getSharedPreferences(PREFS,0).edit().putString("phone",phone.text.toString()).putString("pin",pin.text.toString()).apply();Toast.makeText(this,s("تم حفظ الإعدادات","Settings saved"),Toast.LENGTH_SHORT).show()}.setNegativeButton(s("إلغاء","Cancel"),null).show() }
}
