# Mo.F Catalog — Android

A standalone native Android furniture catalog starter app.

## Features in this first build
- Arabic / English interface toggle
- Furniture product catalog with search
- Grid and list layouts
- Product detail dialog with SAR pricing and discounts
- Admin PIN gate (initial PIN: `1234`)
- Add, edit and delete products
- Up to three product photos per item
- Local persistence using Android SharedPreferences
- Showroom phone number setting and Android dialer action
- GitHub Actions workflow to build a debug APK

## Build
Open this folder in Android Studio, or run `gradle assembleDebug` with JDK 17 and Gradle 8.9.
The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important setup
1. Install the app and open Admin (initial PIN `1234`).
2. Open Showroom settings and enter the showroom phone number.
3. Change the admin PIN immediately.

## Current scope
This initial release stores data on the device. Automatic multi-device cloud synchronization, customer accounts, and a public online catalog require a backend and are not enabled in this starter build.
